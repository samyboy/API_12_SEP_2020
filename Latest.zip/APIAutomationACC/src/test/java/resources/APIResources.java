package resources;

public enum APIResources {
	
	
	AddTransaction("/memberwallet/api/addAccumTransaction"),
	GetTransaction("/memberwallet/api/getaccumssbyhccc");
	
	
	private String resource;
	
	/*
	 * When we are calling constructor we are loading value of the resources mentioned above
	 */
	APIResources(String resource) {
		this.resource=resource;
			
	}
	
	public String getResource() {
		return resource;
	}
	
	

}