//package pojo;
//import com.fasterxml.jackson.annotation.JsonProperty;
//
//public class JsonResponseData {
//
//	public String MatchIndicator;
//	public String ServiceStatus;
//
//	public String ErrorCode;
//	public String ErrorDescription;
//	public String ErrorType;
//
//	public String MemberHCId;
//
//	public String MemberCode;
//	
//	public String MemberCase;
//	public String MemberContract;
//	
//	@JsonProperty("Amount")
//	public double amount;
//	
//	public int Days;
//	public int Visits;
//	public String ClassicAccumName;
//	public String ClaimNetwork;
//	
//	
//	@JsonProperty("AccumStartDate")
//	public String AccumStartDate;
//	@JsonProperty("AccumEndDate")
//	public String AccumEndDate;
//
//	public String getMatchIndicator() {
//		return MatchIndicator;
//	}
//	public void setMatchIndicator(String MatchIndicator) {
//		this.MatchIndicator = MatchIndicator;
//	}
//
//	public String getServiceStatus() {
//		return ServiceStatus;
//	}
//	public void setServiceStatus(String ServiceStatus) {
//		this.ServiceStatus = ServiceStatus;
//	}
//	public String getErrorCode() {
//		return ErrorCode;
//	}
//	public void setErrorCode(String ErrorCode) {
//		this.ErrorCode = ErrorCode;
//	}
//	public String getErrorType() {
//		return ErrorType;
//	}
//	public void setErrorType(String ErrorType) {
//		this.ErrorType = ErrorType;
//	}
//
//	public String getErrorDescription() {
//		return ErrorDescription;
//	}
//	public void setErrorDescription(String ErrorDescription) {
//		this.ErrorDescription = ErrorDescription;
//	}
//	public String getMemberHCId() {
//		return MemberHCId;
//	}
//	public void setMemberHCId(String memberHCID) {
//		MemberHCId = memberHCID;
//	}
//	public String getMemberCode() {
//		return MemberCode;
//	}
//	public void setMemberCode(String memberCode) {
//		MemberCode = memberCode;
//	}
//	public String getMemberCase() {
//		return MemberCase;
//	}
//	public void setMemberCase(String memberCase) {
//		MemberCase = memberCase;
//	}
//	public String getMemberContract() {
//		return MemberContract;
//	}
//	public void setMemberContract(String memberContract) {
//		MemberContract = memberContract;
//	}
//	public double getAmount() {
//		return amount;
//	}
//	public void setAmount(double amount) {
//		this.amount = amount;
//	}
//	public int getDays() {
//		return Days;
//	}
//	public void setDays(int days) {
//		Days = days;
//	}
//	public int getVisits() {
//		return Visits;
//	}
//	public void setVisits(int visits) {
//		Visits = visits;
//	}
//	public String getClassicAccumName() {
//		return ClassicAccumName;
//	}
//	public void setClassicAccumName(String classicAccumName) {
//		ClassicAccumName = classicAccumName;
//	}
//	public String getClaimNetwork() {
//		return ClaimNetwork;
//	}
//	public void setClaimNetwork(String claimNetwork) {
//		ClaimNetwork = claimNetwork;
//	}
//	public String getAccumStartDate() {
//		return AccumStartDate;
//	}
//	public void setAccumStartDate(String accumStartDate) {
//		AccumStartDate = accumStartDate;
//	}
//	public String getAccumEndDate() {
//		return AccumEndDate;
//	}
//	public void setAccumEndDate(String accumEndDate) {
//		AccumEndDate = accumEndDate;
//	}
//	@Override
////	public String toString() {
////		return "JsonResponseData [ServiceStatus="+ServiceStatus+",ErrorCode="+ErrorCode+",ErrorType="+ErrorType+",ErrorDescription="+ErrorDescription+",MatchIndicator=" + MatchIndicator + ",MemberHCID=" + MemberHCId + ", MemberCode=" + MemberCode + ", MemberCase="
////				+ MemberCase + ", MemberContract=" + MemberContract + ", amount=" + amount + ", Days=" + Days
////				+ ", Visits=" + Visits + ", ClassicAccumName=" + ClassicAccumName + ", ClaimNetwork=" + ClaimNetwork
////				+ ", AccumStartDate=" + AccumStartDate + ", AccumEndDate=" + AccumEndDate + "]";
////	}
//	public String toString() {
//		return "JsonResponseData [ErrorDescription="+ErrorDescription+",MatchIndicator=" + MatchIndicator + ",MemberHCID=" + MemberHCId + ", MemberCode=" + MemberCode + ", MemberCase="
//				+ MemberCase + ", MemberContract=" + MemberContract + ", amount=" + amount + ", Days=" + Days
//				+ ", Visits=" + Visits + ", ClassicAccumName=" + ClassicAccumName + ", ClaimNetwork=" + ClaimNetwork
//				+ ", AccumStartDate=" + AccumStartDate + ", AccumEndDate=" + AccumEndDate + "]";
//	}
//
//	
//	
//}
