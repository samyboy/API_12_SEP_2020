package pojo;

import com.opencsv.bean.BeanField;
import com.opencsv.bean.ColumnPositionMappingStrategy;
import com.opencsv.bean.CsvBindByName;
import com.opencsv.exceptions.CsvRequiredFieldEmptyException;

public class AddTransaction {

	@CsvBindByName(column = "claimReasonText")
	private String claimReasonText;
	
	@CsvBindByName(column = "memberHCId")
	private String memberHCId;
	
	@CsvBindByName(column = "transactionPath")
	private String transactionPath;
	
	@CsvBindByName(column = "serviceStartDate")
	private String serviceStartDate;
	
	@CsvBindByName(column = "providerTaxId")
	private String providerTaxId;
	
	@CsvBindByName(column = "memberCode")
	private String memberCode;
	
	@CsvBindByName(column = "providerLicenseNo")
	private String providerLicenseNo;
	
	@CsvBindByName(column = "accumName")
	private String accumName;
	
	@CsvBindByName(column = "sourceSystemClaimId")
	private String sourceSystemClaimId;
	
	@CsvBindByName(column = "memberContract")
	private String memberContract;
	
	@CsvBindByName(column = "serviceEndDate")
	private String serviceEndDate;
	
	@CsvBindByName(column = "lastUpdtUsrId")
	private String lastUpdtUsrId;
	
	@CsvBindByName(column = "organizationCode")
	private String organizationCode;
	
	@CsvBindByName(column = "visits")
	private int visits;
	
	@CsvBindByName(column = "claimSource")
	private String claimSource;
	
	@CsvBindByName(column = "providerNPIId")
	private String providerNPIId;
	
	@CsvBindByName(column = "memberSource")
	private String memberSource;
	
	@CsvBindByName(column = "accumStartDate")
	private String accumStartDate;
	
	@CsvBindByName(column = "claimId")
	private String claimId;
	
	@CsvBindByName(column = "days")
	private int days;
	
	@CsvBindByName(column = "memberCase")
	private String memberCase;
	
	@CsvBindByName(column = "accumEndDate")
	private String accumEndDate;
	
	@CsvBindByName(column = "amount")
	private double amount;
	
	@CsvBindByName(column = "memberTier")
	private String memberTier;
	
	@CsvBindByName(column = "productType")
	private String productType;
	
	@CsvBindByName(column = "diagnosisCode")
	private String diagnosisCode;
	
	@CsvBindByName(column = "claimNetwork")
	private String claimNetwork;

	public String getClaimReasonText() {
		return claimReasonText;
	}

	public void setClaimReasonText(String claimReasonText) {
		this.claimReasonText = claimReasonText;
	}

	public String getMemberHCId() {
		return memberHCId;
	}

	public void setMemberHCId(String memberHCId) {
		this.memberHCId = memberHCId;
	}

	public String getTransactionPath() {
		return transactionPath;
	}

	public void setTransactionPath(String transactionPath) {
		this.transactionPath = transactionPath;
	}

	public String getServiceStartDate() {
		return serviceStartDate;
	}

	public void setServiceStartDate(String serviceStartDate) {
		this.serviceStartDate = serviceStartDate;
	}

	public String getProviderTaxId() {
		return providerTaxId;
	}

	public void setProviderTaxId(String providerTaxId) {
		this.providerTaxId = providerTaxId;
	}

	public String getMemberCode() {
		return memberCode;
	}

	public void setMemberCode(String memberCode) {
		this.memberCode = memberCode;
	}

	public String getProviderLicenseNo() {
		return providerLicenseNo;
	}

	public void setProviderLicenseNo(String providerLicenseNo) {
		this.providerLicenseNo = providerLicenseNo;
	}

	public String getAccumName() {
		return accumName;
	}

	public void setAccumName(String accumName) {
		this.accumName = accumName;
	}

	public String getSourceSystemClaimId() {
		return sourceSystemClaimId;
	}

	public void setSourceSystemClaimId(String sourceSystemClaimId) {
		this.sourceSystemClaimId = sourceSystemClaimId;
	}

	public String getMemberContract() {
		return memberContract;
	}

	public void setMemberContract(String memberContract) {
		this.memberContract = memberContract;
	}

	public String getServiceEndDate() {
		return serviceEndDate;
	}

	public void setServiceEndDate(String serviceEndDate) {
		this.serviceEndDate = serviceEndDate;
	}

	public String getLastUpdtUsrId() {
		return lastUpdtUsrId;
	}

	public void setLastUpdtUsrId(String lastUpdtUsrId) {
		this.lastUpdtUsrId = lastUpdtUsrId;
	}

	public String getOrganizationCode() {
		return organizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}

	public int getVisits() {
		return visits;
	}

	public void setVisits(int visits) {
		this.visits = visits;
	}

	public String getClaimSource() {
		return claimSource;
	}

	public void setClaimSource(String claimSource) {
		this.claimSource = claimSource;
	}

	public String getProviderNPIId() {
		return providerNPIId;
	}

	public void setProviderNPIId(String providerNPIId) {
		this.providerNPIId = providerNPIId;
	}

	public String getMemberSource() {
		return memberSource;
	}

	public void setMemberSource(String memberSource) {
		this.memberSource = memberSource;
	}

	public String getAccumStartDate() {
		return accumStartDate;
	}

	public void setAccumStartDate(String accumStartDate) {
		this.accumStartDate = accumStartDate;
	}

	public String getClaimId() {
		return claimId;
	}

	public void setClaimId(String claimId) {
		this.claimId = claimId;
	}

	public int getDays() {
		return days;
	}

	public void setDays(int days) {
		this.days = days;
	}

	public String getMemberCase() {
		return memberCase;
	}

	public void setMemberCase(String memberCase) {
		this.memberCase = memberCase;
	}

	public String getAccumEndDate() {
		return accumEndDate;
	}

	public void setAccumEndDate(String accumEndDate) {
		this.accumEndDate = accumEndDate;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getMemberTier() {
		return memberTier;
	}

	public void setMemberTier(String memberTier) {
		this.memberTier = memberTier;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getDiagnosisCode() {
		return diagnosisCode;
	}

	public void setDiagnosisCode(String diagnosisCode) {
		this.diagnosisCode = diagnosisCode;
	}

	public String getClaimNetwork() {
		return claimNetwork;
	}

	public void setClaimNetwork(String claimNetwork) {
		this.claimNetwork = claimNetwork;
	}

}